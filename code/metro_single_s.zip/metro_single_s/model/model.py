import torch.nn as nn
import torch
from .layers import *

class METRO_a(nn.Module):
    def __init__(self,device,stride,batch_size, feature_dim, window, d_inner, n_head, d_k, d_v, kernel_sizes, channel, n_attnlayer,
                 n_mlplayer,  embed_dim, dropout=0.1):
        super().__init__()

        self.device=device
        self.batch_size=batch_size
        self.feature_dim=feature_dim

        self.window=window

        self.d_inner=d_inner
        self.n_head=n_head
        self.d_k=d_k
        self.d_v=d_v
        self.dropout=dropout

        self.kernel_sizes=kernel_sizes
        self.channel=channel

        self.n_attnlayer=n_attnlayer
        self.n_mlplayer=n_mlplayer

        self.embed_dim=embed_dim
        self.stride=stride
        self.HI=True

        self.embed_dims=[]
        for i in range(self.n_mlplayer):
            self.embed_dims.append(self.embed_dim)

        self.build_model()

    def build_model(self):

        self.convs=nn.ModuleList()
        self.ss_attn=nn.ModuleList()
        self.cs_attn=nn.ModuleList()

        for kernel_size in self.kernel_sizes:
            self.convs.append(
                nn.Conv2d(in_channels=1, out_channels=self.channel, kernel_size=(1, kernel_size), stride=(1,12), padding=0,
                          bias=True)
            )
            ss_attn_tmp=nn.ModuleList()

            for _ in range(self.n_attnlayer):
                ss_attn_tmp.append(
                    TransformerBlock(d_model=self.channel,
                                     d_inner=self.d_inner,
                                     n_head=self.n_head,
                                     d_k=self.d_k,
                                     d_v=self.d_v,
                                     dropout=self.dropout)
                )
            self.ss_attn.append(ss_attn_tmp)
        cs_attn_tmp=nn.ModuleList()
        for _ in range(self.n_attnlayer):
            cs_attn_tmp.append(
                TransformerBlock(d_model=self.channel,
                                 d_inner=self.d_inner,
                                 n_head=self.n_head,
                                 d_k=self.d_k,
                                 d_v=self.d_v,
                                 dropout=self.dropout)
            )
        self.cs_attn.append(cs_attn_tmp)

        self.out_mlp=MultiLayerPerceptron(7*self.channel, self.embed_dims, self.dropout, output_layer=True)


    def forward(self, X):
        #The inertia
        X0 = X[:, -1, :]

        X=X.permute(0, 2, 1)
        X=X.unsqueeze(1)

        #Embedding
        s1=self.convs[0](X)
        s2=self.convs[1](X)
        s3=self.convs[2](X)
        w1 = s1.shape[-1]
        w2 = s2.shape[-1]
        w3 = s3.shape[-1]

        s1=s1.permute(0, 2, 3, 1)
        s2=s2.permute(0, 2, 3, 1)
        s3=s3.permute(0, 2, 3, 1)

        s1=nn.Sigmoid()(s1)
        s2=nn.Sigmoid()(s2)
        s3 =nn.Sigmoid()(s3)
        s1 = s1.reshape((s1.shape[0],-1,s1.shape[-1]))
        s2 = s2.reshape((s2.shape[0], -1, s2.shape[-1]))
        s3 = s3.reshape((s3.shape[0], -1, s3.shape[-1]))

        #Single-scale update
        for i in range(self.n_attnlayer):
            s1, attn_s1 = self.ss_attn[0][i](s1, s1)
            s2, attn_s2 = self.ss_attn[1][i](s2, s2)
            s3, attn_s3 = self.ss_attn[2][i](s3, s3)
        s1 = s1.reshape((s1.shape[0],self.feature_dim,w1,s1.shape[-1]))
        s2 = s2.reshape((s2.shape[0],self.feature_dim,w2,s2.shape[-1]))
        s3 = s3.reshape((s3.shape[0],self.feature_dim,w3, s3.shape[-1]))

        #Cross-scale fusion
        s=torch.cat((s1[:, :, (-7, -5, -3, -1), :], s2[:, :, (-5, -1), :], s3[:, :, -1, :].unsqueeze(-2)), dim=-2)

        w=s.shape[2]
        s=s.reshape((s.shape[0],-1,s.shape[-1]))

        for i in range(self.n_attnlayer):
            s,attn_s=self.cs_attn[0][i](s,s)
        s=s.reshape((s.shape[0],self.feature_dim,w,s1.shape[-1]))
        s = s.reshape((s.shape[0], self.feature_dim, -1))

        #Predict
        o=self.out_mlp(s)

        if self.HI:
            return (o+X0)/2
        else:
            return o