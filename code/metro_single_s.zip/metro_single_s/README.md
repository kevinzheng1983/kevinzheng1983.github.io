# METRO
This is the code of METRO for single-step multi-variate time series (MTS) forecasting.

## Dependencies
* **python** 3.6.4
* **numpy** 1.16.4
* **torch** 1.2.0
* **matplotlib** 2.1.2

## Data
Data files should be added in the data folder, i.e.,
```
metro-single-s/data/xxx.txt
```
Sample input format can be found through https://github.com/laiguokun/multivariate-time-series-data

## Training the Network
After navigating to /metro-single-s, the following line will initiate the training of a new network with Optuna.

```
python main.py
```

For the first time of running, a log folders will be automatically created with subfolders named by the dataset in the following path:
```
metro-single-s/log/dataset_name/
```
, and a model saving folder will be automatically created at:
```
metro-single-s/saved_models/
```

